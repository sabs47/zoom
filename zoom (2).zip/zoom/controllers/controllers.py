# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import werkzeug
from odoo.tools import format_datetime, format_date, is_html_empty
from odoo.exceptions import UserError
from odoo.addons.survey.controllers.main import Survey
import json

class Zoom(http.Controller):
  def create_order_lines_from_template(order_id,template_lines):
    for line in template_lines:
          #create_order.write({'order_line': [(4, line.id)]}) 
          product=request.env['product.product'].search([('id','=',int(line.product_id))])
          
          create_line=request.env['sale.order.line'].create(
            {'order_id': int(order_id),
              'product_id':int(line.product_id),
              'price_unit':float(product.lst_price)
              #'price_unit':2
                          
              })
    return True



  @http.route('/zoom/hello', auth='public', website=True)
  def index(self, **kw):
   return http.request.render('zoom.index')
   #return "Hello, world"

  @http.route('/zoom/zoom/test', auth='public', website=True)
  def index(self, **kw):
    return http.request.render('zoom.index')

  # @http.route('/zoom/action', auth='public', website=True)
  # def action(self, **kw):
  #  return http.request.render('zoom.action_server')

  #ajout d'enregistrement
  @http.route('/zoom/zoom/create', auth='user')
  def create(self, **kw):
    creation=request.env['zoom.zoom'].create({'name': 'test1','value':'valeur'})
    request.env.cr.commit()
    #self.env['zoom.zoom']._create_object
    result=request.env['zoom.zoom'].search([])
    count = str(len(result))
    return "creation effectuée "+count+ "enregistrements"
 
  @http.route('/zoom/object_id/', auth='user')
  def get_partner_id(self,object_name,field_name,field_value, **kw):
    result=request.env[object_name].search([(field_name,'=',field_value)])
    if bool(result):
      id=result[0].id
      return "id="+str(id)
    else:
      return "enregistrement non trouvé"
  
  @http.route('/zoom/order/create', auth='user')
  def create_order(self,partner_id,th1=None,th2=None,**kw):
      templates={}
      template_lines={}
      if th1:
        templates[1]=request.env['sale.order.template'].search([('id','=',int(th1))])
        template_lines[1]=request.env['sale.order.template.line'].search([('sale_order_template_id','=',int(th1))])
      if th2:
        templates[2]=request.env['sale.order.template'].search([('id','=',int(th2))])
        template_lines[2]=request.env['sale.order.template.line'].search([('sale_order_template_id','=',int(th2))])

      #return ""      
      template_description_final=""
      default_template=request.env['sale.order.template'].search([('id','=',3)])

      descript=str(default_template)+str(templates[1].website_description)+str(templates[2].website_description)
      
      
      #Remplacement des chaines dynamique, ex: nom du client
      partner=request.env['res.partner'].search([('id','=',int(partner_id))])

      descript2=descript.replace("{Nom_client}",str(partner.name))

      userid=request.env.context.get('uid')
      
      
      order=request.env['sale.order'].create(
          {'user_id': userid,
            'partner_id':int(partner_id),
            'sale_order_template_id':3,
            'website_description':descript2
                        
          })
      
      #request.env.cr.commit()
      
      #on boucle sur les produit du template pour les ajouter
      #for tl in template_lines:
      #result=self.create_order_lines_from_template(int(order.id),template_lines[1])
      
      create_line=request.env['sale.order.line'].create(
                {'order_id': int(order.id),
                  'display_type':'line_section',
                  'name':str(templates[1].name),
                  'sequence':1
                
                              
                  })

      
     
      for line in template_lines[1]:
          #create_order.write({'order_line': [(4, line.id)]}) 
          product=request.env['product.product'].search([('id','=',int(line.product_id))])
          
          create_line=request.env['sale.order.line'].create(
            {'order_id': int(order.id),
              'product_id':int(line.product_id),
              'price_unit':float(product.lst_price)
              #'price_unit':2
                          
              })
         
      #ol=request.env['sale.order.line'].search([('order_id','=',int(order.id))])
      #maxi = max(ol.sequence)

      create_line=request.env['sale.order.line'].create(
            {'order_id': int(order.id),
              'display_type':'line_section',
              'name':str(templates[2].name)
              
            
                          
              })

      for line in template_lines[2]:
        #create_order.write({'order_line': [(4, line.id)]}) 
        product=request.env['product.product'].search([('id','=',int(line.product_id))])
        
        create_line=request.env['sale.order.line'].create(
          {'order_id': int(order.id),
            'product_id':int(line.product_id),
            'price_unit':float(product.lst_price)
            #'price_unit':2
                        
            })
        

      #return result
      return werkzeug.utils.redirect('/web#id='+str(order.id)+'&action=331&model=sale.order&view_type=form&cids=1%2C2&menu_id=208')

  @http.route('/zoom/survey/start_with_id', auth='user')
  def create_survey(self,partner_id,survey_id, **kw):
    
    
    
    #récupération des tokens pour afficher l'url de l'equête
    survey=request.env['survey.survey'].search([('id','=',survey_id)])
    access_token=survey[0].access_token
    survey_partner=request.env['survey.user_input'].search([('survey_id','=',int(survey_id)),('partner_id','=',int(partner_id))])
    #nb=len(survey_partner)
    #return 'toto' 

    #si l'enquête existe déjà on affiche le questionnaire
    if bool(survey_partner):
      
      answer_token=survey_partner[0].access_token
      
      return werkzeug.utils.redirect('/survey/start/'+access_token+'?answer_token='+answer_token)
      
      #return request.redirect('/survey/start/'+access_token+'?answer_token='+answer_token)

    else:
      create_survey=request.env['survey.user_input'].create(
        {'survey_id': int(survey_id),
        #'start_datetime ':'',
        'state':'new',
        'partner_id':partner_id


        })
      request.env.cr.commit()
      
      #récupération des tokens pour afficher l'url de l'equête
      survey_partner=request.env['survey.user_input'].search([('id','=',int(survey_id)),('partner_id','=',partner_id)])
      answer_token=survey_partner[0].access_token
      #redirection vers l'enquête pour saisir
      return werkzeug.utils.redirect('/survey/start/'+access_token+'?answer_token='+answer_token)

  @http.route('/zoom/survey_user', auth='user')
  def survey_user(self, **kw):
    surveys_user_input=request.env['survey.user_input'].search([])
    # count = str(len(surveys_user_input))
    # return count
    return http.request.render('zoom.survey_user', {
             'surveys_user_input': surveys_user_input,
         })
  @http.route('/zoom/survey', auth='user')
  def survey(self, **kw):
    surveys=request.env['survey.survey'].search([])
    # count = str(len(surveys_user_input))
    # return count
    return http.request.render('zoom.survey', {
             'surveys': surveys,
         })
    
  #affichage d'un modèle (devis) dans une page web
  @http.route('/zoom/order', auth='user')
  def list(self, **kw):
   orders = http.request.env['sale.order'].search([])
   
   #avec un filtre
   #orders = http.request.env['sale.order'].search([('name','=', 'S00044')])

   return http.request.render('zoom.list', {
             'orders': orders,
         })
  
  @http.route('/zoom/devis/duplique', auth='user')
  def duplique_devis(self,order_id, **kw):
    
    #duplication du devis
    order=request.env['sale.order'].search([('id','=',order_id)])
    params={}
    data = dict()
    data['partner_id']=order.partner_id
    # create_order=request.env['sale.order'].create(
    #     {'user_id': int(order.user_id),
    #      'partner_id':int(order.partner_id),
    #      'order_line' :order.order_line,
    #      'sale_order_template_id':int(order.sale_order_template_id)

    #     })
    #request.env.cr.commit()

    #Si le compte utilisateur pour le contact n'existe pas alors on le créé
    user_account=request.env['res.users'].search([('partner_id','=',int(order.partner_id))])
    if not bool(user_account):
      
      #le compte utilsiateur n'existe pas : on créer le compte
      # create_order=request.env['sale.order'].create(
      #   {'partner_id':int(order.partner_id



      #   })
      
      
      
      
      return "compte créee"

  # @http.route('/zoom/survey/start/<string:survey_token>', type='http', auth='public', website=True)
  # def survey_start(self, survey_token, answer_token=None, email=False, **post):
  #     """ Start a survey by providing
  #       * a token linked to a survey;
  #       * a token linked to an answer or generate a new token if access is allowed;
  #     """
      
  #     # Get the current answer token from cookie
  #     if not answer_token:
  #         answer_token = request.httprequest.cookies.get('survey_%s' % survey_token)
  #     surveyctl=Survey()
  #     access_data = surveyctl._get_access_data(survey_token,answer_token, ensure_token=False)
      
  #     if access_data['validity_code'] is not True:
  #         return Survey._redirect_with_error(access_data, access_data['validity_code'])

  #     survey_sudo, answer_sudo = access_data['survey_sudo'], access_data['answer_sudo']
  #     if not answer_sudo:
  #         try:
  #             answer_sudo = survey_sudo._create_answer(user=request.env.user, email=email)
  #         except UserError:
  #             answer_sudo = False

  #     if not answer_sudo:
  #         try:
  #             survey_sudo.with_user(request.env.user).check_access_rights('read')
  #             survey_sudo.with_user(request.env.user).check_access_rule('read')
  #         except:
  #             return werkzeug.utils.redirect("/")
  #         else:
  #             return request.render("survey.survey_403_page", {'survey': survey_sudo})

  #     return request.redirect('/zoom/survey/%s/%s' % (survey_sudo.access_token, answer_sudo.access_token))

  # @http.route('/zoom/survey/<string:survey_token>/<string:answer_token>', type='http', auth='public', website=True)
  # def survey_display_page(self, survey_token, answer_token, **post):
  #       surveyctl=Survey()
  #       access_data = surveyctl._get_access_data(survey_token, answer_token, ensure_token=True)
  #       if access_data['validity_code'] is not True:
  #           return Survey._redirect_with_error(access_data, access_data['validity_code'])

  #       answer_sudo = access_data['answer_sudo']
  #       if answer_sudo.state != 'done' and answer_sudo.survey_time_limit_reached:
  #           answer_sudo._mark_done()

  #       return request.render('zoom.tsurvey_page_fill_du',
  #           surveyctl._prepare_survey_data(access_data['survey_sudo'], answer_sudo, **post))

  # @http.route('/zoom/survey/print/<string:survey_token>', type='http', auth='public', website=True, sitemap=False)
  # def survey_print(self, survey_token, review=False, answer_token=None, **post):
  #     '''Display an survey in printable view; if <answer_token> is set, it will
  #     grab the answers of the user_input_id that has <answer_token>.'''
  #     surveyctl=Survey()
  #     access_data = Survey._get_access_data(survey_token, answer_token, ensure_token=False)
  #     if access_data['validity_code'] is not True and (
  #             access_data['has_survey_access'] or
  #             access_data['validity_code'] not in ['token_required', 'survey_closed', 'survey_void']):
  #         return Survey._redirect_with_error(access_data, access_data['validity_code'])

  #     survey_sudo, answer_sudo = access_data['survey_sudo'], access_data['answer_sudo']

  #     return request.render('survey.survey_page_print_du', {
  #         'is_html_empty': is_html_empty,
  #         'review': review,
  #         'survey': survey_sudo,
  #         'answer': answer_sudo if survey_sudo.scoring_type != 'scoring_without_answers' else answer_sudo.browse(),
  #         'questions_to_display': answer_sudo._get_print_questions(),
  #         'scoring_display_correction': survey_sudo.scoring_type == 'scoring_with_answers' and answer_sudo,
  #         'format_datetime': lambda dt: format_datetime(request.env, dt, dt_format=False),
  #         'format_date': lambda date: format_date(request.env, date),
  #     })

    
    
    
    
