# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from werkzeug import utils

class SurveyInherit(models.Model):
    _inherit='survey.survey'

class ResPartnerInherit(models.Model):
    _inherit='res.partner'
    url_audit_flash=fields.Char('Audit Flash', default=lambda self: self.get_id())
    def get_id(self):
        return self.id

    def action_start_survey(self):
        
        return { 'type': 'ir.actions.act_url',
         'url': '/zoom/survey/start_with_id?partner_id='+str(self.id)+'&survey_id=1',
         'target': 'self'}
         

# class SaleOrderInherit(models.Model):
#     _inherit='sale.order'
#     patient_name=fields.Char(String='Patient Name')

class SaleOrderInherit(models.Model):
    _inherit='sale.order'
    duplicate_id=fields.Integer('id du devis dupliqué',default=None)


    def action_duplicate_order_du(self):

              
       #Duplication du devis
        order=self.env['sale.order'].search([('id','=',int(self.id))])

        dup_order=order.copy()

       
        # create_order=self.env['sale.order'].create(
        #     {'user_id': int(order.user_id),
        #      'partner_id':int(order.partner_id),
        #      'order_line' :dup_order.order_line,
        #      'sale_order_template_id':int(order.sale_order_template_id),
        #      'duplicate_id' : int(self.id)

        #     })
       
        dup_order.duplicate_id= int(self.id)
        self.env.cr.commit()
        
        #remise à  zéro des montants pour le devis dupliqué
        order_lines=self.env['sale.order.line'].search([('order_id','=',int(dup_order.id))])
        
        for order_line in order_lines:
            order_line.price_unit=0
            order_line.price_total=0
        self.env.cr.commit()

        #modification des droits utilisateurs
        user_account=self.env['res.users'].search([('partner_id','=',int(order.partner_id))])
        user = user_account.partner_id.user_ids[0] if user_account.partner_id.user_ids else None
        if not bool(user_account):
            raise UserError("le compte utilisateur n'existe pas, Aller sur la fiche contact et donner l'accès portal")
        else:
            #on vérifie que le compte est de type interne sinon on modifie l'utilisateur
            group_user = self.env.ref('base.group_user')
            group_portal=self.env.ref('base.group_portal')

            #on l'enleve du groupe portal
            if group_portal in user_account.groups_id:

                    user_account.write({'groups_id': [(3, group_portal.id)]})
                    self.env.cr.commit()
                    #raise UserError("utilisateur enlevé du groupo portal")
                    #return
            #on l'ajoute au groupe interne
            if group_user not in user_account.groups_id:
                    user_account.write({'active': True, 'groups_id': [(4, group_user.id)]})
                    self.env.cr.commit()
            
            group_client=self.env['res.groups'].search([('name','=','Group_client')])
            trouve=False
            
            for group_id in user_account.groups_id:
                
                if int(group_id)==int(group_client.id):
                    trouve=True
            if trouve==False:
             #le compte existe mais le groupe client n'existe pas" : le rajoute
             user_account.write({'groups_id':[(4,group_client.id)]})
             self.env.cr.commit()
            raise UserError("opération effectuée")
             
class zoom(models.Model):
     _name = 'zoom.zoom'
     _description = 'zoom.zoom'

     name = fields.Char()
     value = fields.Text()
     #value2 = fields.Float(compute="_value_pc", store=True)
     #description = fields.Text()

     @api.depends('value')
     def _value_pc(self):
         for record in self:
             record.value2 = float(record.value) / 100
# def action_duplicate_accounts(self):
#         for account in self.browse(self.env.context['active_ids']):
#             account.copy()
     
     
     def _create_object(self):
         creation=self.env['zoom.zoom'].create({'name': 'test1','value':'valeur'})
         self.env.cr.commit()
         result=self.env['zoom.zoom'].search([])
         count = len(result)
         return count

     def action_duplicate_order_du(self):
         return "coucou"
         
class search(models.Model):
    _inherit = 'res.partner'
    vehicle_count = fields.Integer()
    def get_vehicles(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vehicles',
            'view_mode': 'tree',
            'res_model': 'fleet.vehicle',
            'domain': [('driver_id', '=', self.id)],
            'context': "{'create': False}"
        }
    def compute_count(self):
        for record in self:
            record.vehicle_count = self.env['fleet.vehicle'].search_count(
                [('driver_id', '=', self.id)])