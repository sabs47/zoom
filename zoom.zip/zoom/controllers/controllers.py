# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from werkzeug import utils

class Zoom(http.Controller):
  @http.route('/zoom/hello', auth='public', website=True)
  def index(self, **kw):
   return http.request.render('zoom.index')
   #return "Hello, world"

  @http.route('/zoom/zoom/test', auth='public', website=True)
  def index(self, **kw):
    return http.request.render('zoom.index')

  # @http.route('/zoom/action', auth='public', website=True)
  # def action(self, **kw):
  #  return http.request.render('zoom.action_server')

  #ajout d'enregistrement
  @http.route('/zoom/order/create', auth='user')
  def create(self, **kw):
    creation=request.env['zoom.zoom'].create({'name': 'test1','value':'valeur'})
    request.env.cr.commit()
    #self.env['zoom.zoom']._create_object
    result=request.env['zoom.zoom'].search([])
    count = str(len(result))
    return "creation effectuée "+count+ "enregistrements"
 
  @http.route('/zoom/object_id/', auth='user')
  def get_partner_id(self,object_name,field_name,field_value, **kw):
    result=request.env[object_name].search([(field_name,'=',field_value)])
    if bool(result):
      id=result[0].id
      return "id="+str(id)
    else:
      return "enregistrement non trouvé"


  @http.route('/zoom/survey/create', auth='user')
  def create_survey(self,partner_id,survey_id, **kw):
    
    
    
    #récupération des tokens pour afficher l'url de l'equête
    survey=request.env['survey.survey'].search([('id','=',survey_id)])
    access_token=survey[0].access_token
    survey_partner=request.env['survey.user_input'].search([('survey_id','=',int(survey_id)),('partner_id','=',int(partner_id))])
    #nb=len(survey_partner)
    #return 'toto' 

    #si l'enquête existe déjà on affiche le questionnaire
    if bool(survey_partner):
      
      answer_token=survey_partner[0].access_token
      
      return utils.redirect('/survey/start/'+access_token+'?answer_token='+answer_token)
      
      #return request.redirect('/survey/start/'+access_token+'?answer_token='+answer_token)

    else:
      create_survey=request.env['survey.user_input'].create(
        {'survey_id': int(survey_id),
        #'start_datetime ':'',
        'state':'new',
        'partner_id':partner_id


        })
      request.env.cr.commit()
      
      #récupération des tokens pour afficher l'url de l'equête
      survey_partner=request.env['survey.user_input'].search([('id','=',int(survey_id)),('partner_id','=',partner_id)])
      answer_token=survey_partner[0].access_token
      #redirection vers l'enquête pour saisir
      return utils.redirect('/survey/start/'+access_token+'?answer_token='+answer_token)

  @http.route('/zoom/survey_user', auth='user')
  def survey_user(self, **kw):
    surveys_user_input=request.env['survey.user_input'].search([])
    # count = str(len(surveys_user_input))
    # return count
    return http.request.render('zoom.survey_user', {
             'surveys_user_input': surveys_user_input,
         })
  @http.route('/zoom/survey', auth='user')
  def survey(self, **kw):
    surveys=request.env['survey.survey'].search([])
    # count = str(len(surveys_user_input))
    # return count
    return http.request.render('zoom.survey', {
             'surveys': surveys,
         })
    
  #affichage d'un modèle (devis) dans une page web
  @http.route('/zoom/order', auth='user')
  def list(self, **kw):
   orders = http.request.env['sale.order'].search([])
   
   #avec un filtre
   #orders = http.request.env['sale.order'].search([('name','=', 'S00044')])

   return http.request.render('zoom.list', {
             'orders': orders,
         })

