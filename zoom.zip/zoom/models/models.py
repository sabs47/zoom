# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ResPartnerInherit(models.Model):
    _inherit='res.partner'
    url_audit_flash=fields.Char('Audit Flash', default=lambda self: self.get_id())
    def get_id(self):
        return self.id
# class SaleOrderInherit(models.Model):
#     _inherit='sale.order'
#     patient_name=fields.Char(String='Patient Name')
     
class zoom(models.Model):
     _name = 'zoom.zoom'
     _description = 'zoom.zoom'

     name = fields.Char()
     value = fields.Text()
     #value2 = fields.Float(compute="_value_pc", store=True)
     #description = fields.Text()

     @api.depends('value')
     def _value_pc(self):
         for record in self:
             record.value2 = float(record.value) / 100
# def action_duplicate_accounts(self):
#         for account in self.browse(self.env.context['active_ids']):
#             account.copy()
     
     
     def _create_object(self):
         creation=self.env['zoom.zoom'].create({'name': 'test1','value':'valeur'})
         self.env.cr.commit()
         result=self.env['zoom.zoom'].search([])
         count = len(result)
         return count
         
